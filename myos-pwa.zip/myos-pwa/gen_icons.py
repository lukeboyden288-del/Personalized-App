from PIL import Image, ImageDraw, ImageFont
import os

def make_icon(size, path):
    img = Image.new('RGB', (size, size), color='#0f0f0f')
    draw = ImageDraw.Draw(img)
    # Draw a simple "M" logo
    margin = size * 0.2
    font_size = int(size * 0.55)
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', font_size)
    except:
        font = ImageFont.load_default()
    text = 'M'
    bbox = draw.textbbox((0,0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    x = (size - tw) / 2 - bbox[0]
    y = (size - th) / 2 - bbox[1]
    draw.text((x, y), text, fill='#4f9cf9', font=font)
    img.save(path)
    print(f"Created {path}")

make_icon(192, '/home/claude/myos-pwa/icon-192.png')
make_icon(512, '/home/claude/myos-pwa/icon-512.png')
